declare module 'vue-typer';
