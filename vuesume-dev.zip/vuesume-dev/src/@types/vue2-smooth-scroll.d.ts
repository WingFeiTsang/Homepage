declare module 'vue2-smooth-scroll';
