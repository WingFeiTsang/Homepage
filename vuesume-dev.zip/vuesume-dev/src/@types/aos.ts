declare module 'aos';
